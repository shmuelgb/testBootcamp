//import libraries
import React from "react";
import ReactDOM from "react-dom";
import App from './App.js'



//take components and show on screen
ReactDOM.render(<App />, document.querySelector("#root"));
